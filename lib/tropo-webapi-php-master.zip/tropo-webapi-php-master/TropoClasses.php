<?php
// This file is deprecated and is here for backward compatibility
require 'tropo.class.php';
?>

